 <h1 align="center"> 💥BMW MD💥 </h1>
<p align="center"> BMW MD💥, A Simple WhatsApp user BOT, Created by Ibrahim Tech.
</p>



<img src="https://telegra.ph/file/a238340352ed8841782a7.jpg" width="700" height="300"/>

## Support 🧧

<a href="https://chat.whatsapp.com/JE3gJsV15ly9ViU6lgw0GD">
  <img src="https://img.shields.io/badge/Support_Group-0a0a0a?style=for-the-badge&logo=whatsapp&logoColor=white">
</a>

HOW TO REACH THE OWNER? 
 
   
   <a href="https://wa.me/message/74F2PC4JA4F3P1">
    <img src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>&nbsp;&nbsp;
   <a

## Ask any thing


## STEPS TO DEPLOY YOUR BOT

## TAP ON STAR AND FORK THE REPO SOW THAT A BOT CAN WORK IF NOT THE BOT WILL NOT WORK!!

1, Fork the repo

   ***Click [`FORK`](https://github.com/ibrahimaitech/IBRAHIM-AI-10.10) and `Star 👑 Repository` for Courage.***
  


2, Scan the code and link it with your Whatsapp.


  ***Click [`Get Session`](https://ibrahim-tech-1-4a7321f212d3.herokuapp.com/). ("Option 1")
  
  
  ***Click [`Get Session`](https://ibrahim-tech-qr-1-2-1.onrender.com/). ("Option 2")


   
3, Copy the session and deploy on heroku.  

   
 - ***Now [`DEPLOY`](https://dashboard.heroku.com/new?template=https://github.com/ibrahimaitech/IBRAHIM-AI-10.10).***


## Contributions

Contributions to *BMW-MD* are welcome! If you have ideas for new features, improvements, or bug fixes, feel free to open an issue or submit a pull request.

## License

The *BMW-MD* is released under the [MIT License](https://opensource.org/licenses/MIT).

Enjoy the diverse features of the *BMW-MD*  to enhance your Whatsapp more enjoyable


